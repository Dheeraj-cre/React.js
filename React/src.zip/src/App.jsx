import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import StudentRegistration from "./StudentRegistration.jsx";
import StudentList from "./StudentList.jsx";
import Navigation from "./Navigation.jsx";
import "./App.css"; // import css file

function App() {
  return (
    <div className="app-container">
      <BrowserRouter>
        {/* Fixed Navigation */}
        <Navigation />

        {/* Scrollable Content */}
        <div className="content">
          <Routes>
            <Route path="/" element={<StudentRegistration />} />
            <Route path="/studentlist" element={<StudentList />} />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;