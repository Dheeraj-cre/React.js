import React from "react";
import { useDispatch } from "react-redux";
import { useForm } from "react-hook-form";
import { addStudent } from "./studentSlice.js";
import "./StudentRegistration.css"; // Import CSS file

function StudentRegistration() {
  const dispatch = useDispatch();
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  function submitHandler(data) {
    dispatch(addStudent(data));
    alert("Student registered successfully");
    reset();
  }

  return (
    <div className="form-container">
      <h2>Register Student</h2>
      <form onSubmit={handleSubmit(submitHandler)} className="student-form">
        
        <div className="form-group">
          <label>Student Id</label>
          <input type="text" {...register("stdid", { required: "Student id cannot be empty" })} />
          {errors.stdid && <p className="error">{errors.stdid.message}</p>}
        </div>

        <div className="form-group">
          <label>Student Name</label>
          <input type="text" {...register("stdname", { required: "Student Name cannot be empty" })} />
          {errors.stdname && <p className="error">{errors.stdname.message}</p>}
        </div>

        <div className="form-group">
          <label>Standard</label>
          <input type="text" {...register("standard", { required: "Standard cannot be empty" })} />
          {errors.standard && <p className="error">{errors.standard.message}</p>}
        </div>

        <div className="form-group">
          <label>Roll No.</label>
          <input type="text" {...register("roll", { required: "Roll cannot be empty" })} />
          {errors.roll && <p className="error">{errors.roll.message}</p>}
        </div>

        <div className="form-group">
          <label>Age (in Years)</label>
          <input type="text" {...register("age", { required: "Age cannot be empty" })} />
          {errors.age && <p className="error">{errors.age.message}</p>}
        </div>

        <button type="submit" className="submit-btn">Register</button>
      </form>
    </div>
  );
}

export default StudentRegistration;