import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { deleteStudent } from "./studentSlice.js";
import "./StudentList.css"; // Import CSS file

/*--- defining functional component ---*/
function StudentList() {
  const dispatch = useDispatch();
  // fetching array data from Redux store
  const students = useSelector((state) => state.students.students);

  return (
    <div className="list-container">
      <h2>Student List</h2>

      {/*--- checking students array length ---*/}
      {students.length === 0 ? (
        <p className="no-data">No students data found</p>
      ) : (
        <table className="student-table">
          <thead>
            <tr>
              <th>Student Id</th>
              <th>Student Name</th>
              <th>Standard</th>
              <th>Roll No.</th>
              <th>Age</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.stdid}>
                <td>{student.stdid}</td>
                <td>{student.stdname}</td>
                <td>{student.standard}</td>
                <td>{student.roll}</td>
                <td>{student.age}</td>
                <td>
                  <button
                    className="delete-btn"
                    onClick={() => dispatch(deleteStudent(student.stdid))}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default StudentList;