import { Link } from "react-router-dom";
import "./Navigation.css"; // Import CSS file

function Navigation() {
  return (
    <nav className="navbar">
      <Link to="/" className="nav-link">
        Student Registration
      </Link>
      <Link to="/studentlist" className="nav-link">
        Student List
      </Link>
    </nav>
  );
}

export default Navigation;